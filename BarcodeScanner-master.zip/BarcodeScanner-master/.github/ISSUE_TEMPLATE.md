DON'T POST ISSUES HERE, GO TO https://github.com/phonegap/phonegap-plugin-barcodescanner/issues
